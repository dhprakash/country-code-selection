# Country Code Selection

A Pen created on CodePen.io. Original URL: [https://codepen.io/piyushpd139/pen/JjNjzBb](https://codepen.io/piyushpd139/pen/JjNjzBb).

A JavaScript plugin for  international telephone numbers. It adds a flag dropdown to any input, detects the user's country, displays a relevant placeholder and provides formatting/validation methods.